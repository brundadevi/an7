import { Injectable } from '@angular/core';
import { Deto } from './deto';
import { InMemoryDbService } from 'angular-in-memory-web-api';
@Injectable({
  providedIn: 'root'
})
export class InMemoryDataService implements InMemoryDbService {

  constructor() { }

  createDb() {
    const detoes = [
      { id: 1, jobcode: 'Mr. Nice',date:'2020-01-01',batchno:'11',random:'random..1' },
      { id: 225, jobcode: 'Mr. Nice',date:'2018-08-01',batchno:'11',random:'random..3' },
      { id: 2, jobcode: 'Narco',date:'2018-01-01',batchno:'12',random:'yayyyy' },
      { id: 3, jobcode: 'Bombasto',date:'2019-12-01',batchno:'100000000023',random:'random3' },
      { id: 4 , jobcode: 'Mr. Nice',date:'2019-01-01',batchno:'11',random:'random..2' },
      { id: 17, jobcode: 'Narco',date:'2018-01-01',batchno:'12',random:'random2' },
      { id: 16, jobcode: 'Bombasto',date:'2019-07-01',batchno:'12',random:'random3' },
      { id: 221, jobcode: 'Mr. Nice',date:'2019-08-01',batchno:'11',random:'random..3' },
      { id: 222, jobcode: 'Narco',date:'2018-01-01',batchno:'12',random:'yayyyy' },
      { id: 322, jobcode: 'Bombasto',date:'2019-12-01',batchno:'100000000023',random:'random3' },
      { id: 42, jobcode: 'Mr. Nice',date:'2019-04-01',batchno:'121',random:'random..4' },
      { id: 172, jobcode: 'Narco',date:'2018-04-01',batchno:'12',random:'random2' },
      { id: 162, jobcode: 'Bombasto',date:'2019-03-01',batchno:'12',random:'random3' },
      
    ];
    return {detoes};
  }

  // Overrides the genId method to ensure that a hero always has an id.
  // If the heroes array is empty,
  // the method below returns the initial number (11).
  // if the heroes array is not empty, the method below returns the highest
  // hero id + 1.
  genId(detoes: Deto[]): number {
    return detoes.length > 0 ? Math.max(...detoes.map(deto => deto.id)) + 1 : 1;
  }
}





