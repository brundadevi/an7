import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule }    from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { AddingComponent } from './adding/adding.component';
import { SearchComponent } from './search/search.component';
import { HttpClientInMemoryWebApiModule } from 'angular-in-memory-web-api';
import { InMemoryDataService }  from './in-memory-data.service';
import {DatahandlingService} from  './datahandling.service';
import {NgxPaginationModule} from 'ngx-pagination';

import { FormsModule } from '@angular/forms';
import { EditsComponent } from './edits/edits.component';
@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    AddingComponent,
    SearchComponent,
    EditsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    NgxPaginationModule,
    HttpClientInMemoryWebApiModule.forRoot(
      InMemoryDataService, { dataEncapsulation: false }
    )
   
  ],
  providers: [DatahandlingService],
  bootstrap: [AppComponent]
})
export class AppModule { }
