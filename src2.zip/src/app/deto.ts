export class Deto {
    id: number;
    jobcode: string;
    date:string;
    batchno:number;
    random:string;

    

  }