import { Deto } from '../deto';
import { DatahandlingService } from '../datahandling.service';
import { NgForm } from '@angular/forms';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edits',
  templateUrl: './edits.component.html',
  styleUrls: ['./edits.component.css']
})
export class EditsComponent implements OnInit {
  detoes: Deto[]=[];
  deto2:Deto[]=[];
  constructor(private ds:DatahandlingService)
     { 

      }
      getDetoes(): void {
        this.ds.getDetoes()
        .subscribe(detoes => {this.detoes = detoes;
        console.log(this.detoes[2].jobcode);
         // this.dm=this.detoes;
         
      })
        console.log("FDhfehgoiegelhgeiojng");
      
       
      }
    delf(deto:Deto)
    {
this.ds.deleteDeto(deto.id).subscribe();
console.log("jklmn"+deto.id);

    }
    editf(deto:Deto)
    {

    console.log("*&^%");
  deto.jobcode=deto.jobcode;
  console.log(deto.date);
  this.ds.upDeto(deto).subscribe();
  console.log(deto);
  
    }

  ngOnInit() {
    this.getDetoes();
  }

}
